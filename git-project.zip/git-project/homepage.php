<?php
include 'db.php'; // Your DB connection
include 'Product.php';
include 'NormalProduct.php';
include 'PremiumProduct.php';
include 'ProductFactory.php';

$conn = db::getInstance()->getConnection(); // singleton pattern if you are using it
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Gemstone Gallery</title>

  <!-- Bootstrap CSS -->
  <link href="./bootstrap_v5.3/css/bootstrap.min.css" rel="stylesheet">
  <link href="./bootstrap-icons-1.13.1/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="bootstrap-icons/bootstrap-icons.css">


  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">

  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet"/>

  <style>
    body {
      background-color: #111;
      color: #fff;
      font-family: "Roboto", sans-serif;
      scroll-behavior: smooth; /* smooth scrolling */
      padding-top: 100px; /* to avoid content hiding under navbar */
    }

    /* --- Fixed Navbar --- */
    .navbar {
      background: linear-gradient(90deg, #000000, #1a1a1a);
      border-bottom: 2px solid gold;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 1000;
      transition: all 0.3s ease;
    }

    .navbar.scrolled {
      background: rgba(0, 0, 0, 0.9);
      backdrop-filter: blur(6px);
      box-shadow: 0 0 10px gold;
    }

    .navbar-brand img {
      height: 70px;
      width: auto;
      margin-left: 30px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .navbar-brand img:hover {
      transform: scale(1.08);
      box-shadow: 0 0 10px gold;
    }

    .navbar-nav .nav-link {
      color: #f1f1f1;
      font-weight: 500;
      letter-spacing: 0.5px;
      margin: 0 8px;
      position: relative;
      transition: color 0.3s ease;
    }

    .navbar-nav .nav-link:hover {
      color: gold;
    }

    .navbar-nav .nav-link::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 0;
      height: 2px;
      background: gold;
      transition: width 0.3s ease;
    }

    .navbar-nav .nav-link:hover::after {
      width: 60%;
    }

    /* --- Search --- */
    .search-box {
      position: relative;
    }

    .search-box input {
      border-radius: 50px;
      padding-left: 38px;
      background-color: #222;
      border: 1px solid #444;
      color: white;
      transition: all 0.3s ease;
      width: 230px;
    }

    .search-box input:focus {
      outline: none;
      border-color: gold;
      background-color: #1a1a1a;
      box-shadow: 0 0 8px gold;
    }

    .search-box .bi-search {
      position: absolute;
      top: 50%;
      left: 12px;
      transform: translateY(-50%);
      color: gold;
    }

    /* --- Dropdown --- */
    .dropdown-menu {
      background-color: #111;
      border: 1px solid gold;
      border-radius: 10px;
      transition: all 0.3s ease;
    }

    .dropdown-item {
      color: #fff;
      transition: all 0.3s ease;
    }

    .dropdown-item:hover {
      background-color: #fff !important;
      color: #000 !important;
      transform: translateX(5px);
    }

    /* --- Video Section --- */
    section video {
      width: 100%;
      height: 85vh;
      object-fit: cover;
      border-bottom: 2px solid gold;
    }

    #toggle-sound {
      position: absolute;
      bottom: 15px;
      right: 15px;
      background-color: rgba(0, 0, 0, 0.7);
      border: 1px solid gold;
      color: gold;
      font-weight: 500;
      padding: 6px 14px;
      border-radius: 25px;
      transition: background-color 0.3s ease;
    }

    #toggle-sound:hover {
      background-color: gold;
      color: black;
    }

    /* --- Marquee --- */
    .gemstone-marquee {
      display: inline-block;
      white-space: nowrap;
      font-family: 'Playfair Display', serif;
      font-size: 18px;
      font-weight: 500;
      color: #f5d67b;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.6);
      animation: scroll-left 18s linear infinite;
    }

    .gemstone-marquee-container {
      background-color: #000;
      overflow: hidden;
      padding: 6px 0;
    }

    @keyframes scroll-left {
      0% { transform: translateX(100%); }
      100% { transform: translateX(-100%); }
    }

    /* --- Product Section --- */
    #products {
      padding: 60px 20px;
      background-color: #0b0b0b;
    }

    .product-card {
      background-color: #1a1a1a;
      border: 1px solid gold;
      border-radius: 12px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .product-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 0 15px gold;
    }

    .product-card img {
      border-radius: 12px 12px 0 0;
      height: 250px;
      object-fit: cover;
    }

    .product-card h5 {
      color: gold;
      font-family: 'Playfair Display', serif;
    }

    .product-card p {
      color: #ccc;
    }

    /* --- Footer --- */
    footer {
      background: #000;
      border-top: 2px solid gold;
      color: #ccc;
      padding: 1rem 0;
    }

    footer a {
      color: gold;
      margin: 0 8px;
      transition: all 0.3s;
    }

    footer a:hover {
      color: white;
      transform: scale(1.1);
    }


  .product-card {
    background: #111;
    border: 1px solid #333;
    border-radius: 12px;
    overflow: hidden;
    position: relative;
    transition: 0.4s;
    overflow: hidden;
    
  }

  .product-card:hover {
    transform: translateY(-8px);
    border-color: gold;
    box-shadow: 0 0 18px gold;
  }

  /* Product Image */
  .product-card img {
    width: 100%;
    height: 280px;
    object-fit: cover;
    transition: transform 0.4s ease;
    transform: scale(1.05);
  }

  .product-card:hover img {
    transform: scale(1.12);
  }

  /* Buttons Overlay */
  .product-overlay {
    position: absolute;
    top: 10px;
    right: 10px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    opacity: 0;
    transition: 0.3s;
    z-index: 50;
  }

  .product-card:hover .product-overlay {
    opacity: 1;
  }

  .icon-btn {
    background: rgba(0, 0, 0, 0.65);
    border: 1px solid gold;
    color: gold;
    padding: 8px 10px;
    border-radius: 50%; .product-overlay {
    position: absolute;
    top: 10px;
    right: 10px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    opacity: 0;
    transition: 0.3s;
  }

  .product-card:hover .product-overlay {
    opacity: 1;
  }
    cursor: pointer;
    transition: 0.3s;
  }

  .icon-btn:hover {
    background: gold;
    color: #000;
  }

  /* Product Text */
  .product-card h5 {
    color: gold;
    font-family: 'Playfair Display', serif;
    font-size: 1.3rem;
  }

  .product-card p {
    color: #ccc;
    margin-bottom: 5px;
  }

  .btn-gold {
    background: gold;
    color: #000;
    border: none;
    padding: 8px 14px;
    border-radius: 4px;
    font-weight: bold;
    transition: 0.3s;
  }

  .btn-gold:hover {
    background: #d4af37;
  }

  .description {
    font-size: 0.9rem;
    color: #aaa;
    font-style: italic;
  }

 .custom-search {
   
    background-color: #222; /* dark background */
    color: #fff !important; /* text color */
  
}
.custom-search::placeholder {
    color: #aaa !important; /* placeholder color */
    opacity: 1; /* ensures visibility */
}

.suggestions { 
    position: absolute; 
    top: 110%; 
    left: 0; 
    width: 100%; 
    max-height: 200px; 
    overflow-y: auto; 
    background: #111;    /* Fixed typo: 'ackground' -> 'background' */
    color: #fff;         /* Fixed typo: 'olor' -> 'color' */
    border: 1px solid gold; 
    border-radius: 8px; 
    z-index: 10000; 
 
}

.suggestions div { 
    padding: 8px 12px; 
    cursor: pointer; 
}

.suggestions div:hover { 
    background-color: #0d6efd; 
    color: #fff; 
}

.stylish-toast {
background: linear-gradient(135deg, #d4af37, #f7e199, #ffe08a);
  color:black !important;
  border: none;
  border-radius: 16px;
  padding: 12px 18px;
  box-shadow: 0 6px 25px rgba(0,0,0,0.25);
  backdrop-filter: blur(10px);
  animation: slideDown 0.6s ease;
  opacity: 0.96;
}

.stylish-toast .btn-close-white {
  filter: brightness(200%);
}

@keyframes slideDown {
  from {
    transform: translateY(-40px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

  </style>
</head>

<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand d-flex align-items-center" href="#">
        <img src="logo11.jpg" alt="Gemstone Gallery Logo">
      </a>

      <button class="navbar-toggler text-white border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <i class="bi bi-list fs-1 text-warning"></i>
      </button>

      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link" href="#"><i class="bi bi-house-door me-1"></i>Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#products"><i class="bi bi-box-seam me-1"></i>Products</a></li>
          <li class="nav-item"><a class="nav-link" href="cart.php"><i class="bi bi-cart me-1"></i>Cart</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php"><i class="bi bi-info-circle me-1"></i>About Us</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php"><i class="bi bi-envelope me-1"></i>Contact</a></li>
        </ul>
      </div>

       <!-- Search Box -->
   <div class="d-flex align-items-center position-relative">
     <div class="search-box me-3">
       <i class="bi bi-search"></i>
    <input type="text" id="search-input" placeholder="Search products..." 
           class="custom-search form-control" autocomplete="off">
    <div id="suggestion-box" class="suggestions"></div>
</div>
</div>

        <div class="dropdown">
          <a href="#" class="d-flex align-items-center bg-dark rounded-circle p-2" data-bs-toggle="dropdown">
            <i class="bi bi-person text-warning fs-5"></i>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item text-white" href="signin.html">My Account</a></li>
            <li><a class="dropdown-item text-danger" href="signin.php" id="logoutButton">Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>

  <!-- Video Section -->
  <section class="position-relative">
    <video autoplay loop muted playsinline id="background-video">
      <source src="animation 1.mp4" type="video/mp4">
      <source src="animation 1.webm" type="video/webm">
    </video>
    <button id="toggle-sound"><span id="mute-text">Unmute</span></button>
  </section>

  <!-- Marquee -->
  <div class="gemstone-marquee-container fst-italic">
    <p class="gemstone-marquee">Discover the Beauty of Gemstones and Accessories that Speak Your Style</p>
  </div>

<div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index: 2000">
  <div id="toast-msg" class="toast stylish-toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body" id="toast-body"></div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  </div>
</div>


<!-- PRODUCTS SECTION -->
<section id="products" class="container text-center py-5" style="background: #000;">
  <h2 class="text-gold mb-4" style="font-family: 'Playfair Display', serif; color: gold;">
    Our Featured Products
  </h2>

  <!-- ROW 1 -->
    <!-- Product 1 -->
    <div class="row">

    <?php
    $sql = "SELECT * FROM products";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

           $product = ProductFactory::create($row);
            $product->render();
        }
    } else {
        echo "<p>No products found.</p>";
    }
    ?>
</div>

</section>


  <!-- Footer -->
  <footer class="text-center mt-3">
    <p class="mb-0">© 2025 Gemstone Gallery. All rights reserved.</p>
    <div class="mt-2">
      <a href="#"><i class="fab fa-facebook-f fs-5"></i></a>
      <a href="#"><i class="fab fa-twitter fs-5"></i></a>
      <a href="#"><i class="fab fa-instagram fs-5"></i></a>
    </div>
  </footer>


  <!-- Bootstrap JS -->
  <script src="./bootstrap_v5.3/js/bootstrap.bundle.min.js"></script>
<script>
const toastEl = document.getElementById('toast-msg');
const toastBody = document.getElementById('toast-body');
const toast = new bootstrap.Toast(toastEl);

document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', () => {
        toastBody.textContent = 'Product added to cart!';
        toast.show();
    });
});

document.querySelectorAll('.add-to-fav').forEach(btn => {
    btn.addEventListener('click', () => {
        toastBody.textContent = 'Product added to favourites!';
        toast.show();
    });
});


    // Navbar scroll effect
    window.addEventListener('scroll', () => {
      const navbar = document.querySelector('.navbar');
      if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });

    // Video mute toggle
    const video = document.getElementById('background-video');
    const toggleSoundButton = document.getElementById('toggle-sound');
    const muteText = document.getElementById('mute-text');
    video.muted = true;
    toggleSoundButton.addEventListener('click', () => {
      video.muted = !video.muted;
      muteText.textContent = video.muted ? 'Unmute' : 'Mute';
    });

const input = document.getElementById("search-input");
const suggestionBox = document.getElementById("suggestion-box");
const form = document.getElementById("search-form");

input.addEventListener("keyup", function() {
    let term = input.value;

    if (term.length === 0) {
        suggestionBox.innerHTML = "";
        return;
    }

    fetch("suggest.php?term=" + term)
        .then(res => res.json())
        .then(data => {
            suggestionBox.innerHTML = "";
            data.forEach(item => {
                let div = document.createElement("div");
                div.textContent = item.name; // assume JSON has 'name' and 'id'
                div.onclick = () => {
                    // Navigate to product page
                    window.location.href = `product-details.php?id=${item.id}`;
                };
                suggestionBox.appendChild(div);
            });
        });
});

// Optional: submit form on Enter
form.addEventListener("submit", (e) => {
    if(input.value.trim() === "") e.preventDefault();
});

  </script>
</body>
</html>
