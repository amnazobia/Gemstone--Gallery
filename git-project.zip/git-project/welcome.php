<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Gemstone Gallery — Welcome</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

  <style>
    body {
      margin: 0;
      padding: 0;
      height: 100vh;
      overflow: hidden;
      background: url('logo1.jpg') center/contain no-repeat #000;
      background-position: center 15%;
      font-family: 'Poppins', sans-serif;
    }

    .overlay {
      position: fixed;
      inset: 0;
      background: linear-gradient(to bottom, rgba(0,0,0,0.85), rgba(0,0,0,0.95));
    }

    .floating-gems {
      position: absolute;
      inset: 0;
      overflow: hidden;
      z-index: 1;
    }

    .gem {
      position: absolute;
      width: 25px;
      height: 25px;
      background: gold;
      opacity: 0.45;
      filter: blur(2px);
      border-radius: 4px;
      animation: floatUp 10s linear infinite;
    }

    @keyframes floatUp {
      0% { transform: translateY(120vh) rotate(0deg); }
      100% { transform: translateY(-20vh) rotate(360deg); }
    }

    .content-box {
      position: relative;
      z-index: 3;
      width: 500px;
      padding: 50px 40px;
      border-radius: 20px;
      background: rgba(255, 255, 255, 0.07);
      backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 0 25px rgba(255, 215, 0, 0.1);
      animation: fadeIn 1s ease-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(40px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .logo {
      width: 140px;
      filter: drop-shadow(0 0 6px #000);
      margin-bottom: 15px;
    }

    h1 {
      font-family: 'Playfair Display', serif;
      font-size: 2.4rem;
      color: gold;
      margin-bottom: 12px;
      letter-spacing: 1px;
    }

    .intro-text {
      font-size: 1rem;
      color: #eee;
      opacity: 0.85;
      margin-bottom: 30px;
    }

    .btn-custom {
      background: gold;
      color: #000;
      padding: 10px 35px;
      border-radius: 30px;
      font-weight: 600;
      transition: 0.3s ease;
      box-shadow: 0 0 12px rgba(255, 215, 0, 0.4);
    }

    .btn-custom:hover {
      background: #d4af37;
      color: #fff;
      transform: scale(1.05);
    }

    .btn-outline-custom {
      border: 2px solid gold;
      color: gold;
      padding: 10px 35px;
      border-radius: 30px;
      font-weight: 600;
      transition: 0.3s ease;
    }

    .btn-outline-custom:hover {
      background: gold;
      color: #000;
      transform: scale(1.05);
    }
  </style>
</head>
<body>

  <div class="overlay"></div>
  <div class="floating-gems">
    <div class="gem" style="left:10%; animation-duration:12s; width:20px;"></div>
    <div class="gem" style="left:25%; animation-duration:15s;"></div>
    <div class="gem" style="left:40%; animation-duration:11s; width:30px;"></div>
    <div class="gem" style="left:60%; animation-duration:14s;"></div>
    <div class="gem" style="left:75%; animation-duration:13s; width:28px;"></div>
  </div>

  <div class="d-flex justify-content-center align-items-center h-100">
    <div class="content-box text-center">
        <img src="product-images\bglogo.png" class="logo" alt="Logo">
        <h1>Welcome to Gemstone Gallery</h1>
        <p class="intro-text">Experience the brilliance, rarity, and timeless beauty of gemstones from around the world.</p>

        <div class="d-flex justify-content-center gap-3 mt-3">
            <a href="register.php" class="btn btn-custom">Register</a>
            <a href="signin.php" class="btn btn-outline-custom">Sign In</a>
        </div>
    </div>
  </div>

</body>
</html>