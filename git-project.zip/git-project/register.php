<?php
include 'db.php';

// Get Singleton DB connection
$conn = db::getInstance()->getConnection();

// Get ID from request
$user_id = isset($_REQUEST['id']) ? $_REQUEST['id'] : 0;

if ($user_id > 0) {

    // Always secure query (avoid SQL injection)
    // $sql = "SELECT * FROM registration WHERE id = ?";
    // $stmt = $conn->prepare($sql);
    // $stmt->bind_param("i", $user_id);
    // $stmt->execute();
    // $result = $stmt->get_result();
    // $user = $result->fetch_assoc();

    if ($user) {
        $full_name     = $user['Full_name'];
        $email         = $user['email'];
        $password       = $user['password'];
        
    }
} 
else {
    $user_id=0;
    $full_name     = "";
    $email         = "";
    $password       = "";
  
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="styles.css">
      <link href="css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons-1.13.1/bootstrap-icons.css">
    <style>
        /* Form Container */
        .form-container {
            width: 100%;
            max-width: 450px;
            margin: 50px auto;
            padding: 20px;
            padding-right: 40px;
            background: #f9f9f9;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            font-family: Arial, sans-serif;
        }

        /* Title and Subtitle */
        h1 {
            text-align: center;
            font-size: 2.2em;
            color: #333;
        }

        .subtitle {
            text-align: center;
            font-size: 1.1em;
            color: #555;
        }

        /* Form Fields */
        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 1em;
        }

        /* Checkbox Container */
        .checkbox-container {
            margin-bottom: 20px;
        }

        /* Button Styles */
        .btn {
            width: 100%;
            padding: 12px;
            color: white;
            font-size: 1.1em;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin-top: 10px;
        }

        .signup-btn {
            background-color: #007BFF;
        }

        .signup-btn:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .signup-btn:active {
            transform: scale(0.98);
        }

        .google-btn {
            background-color: #db4437;
        }

        .google-btn:hover {
            background-color: #c1351d;
            transform: scale(1.05);
        }

        .google-btn:active {
            transform: scale(0.98);
        }

        /* Feedback Message */
        #feedback {
            margin-top: 10px;
            text-align: center;
            color: green;
        }

        /* Divider */
        .divider {
            text-align: center;
            margin: 20px 0;
            font-weight: bold;
            color: #777;
        }

        /* Footer Text */
        .footer-text {
            text-align: center;
            margin-top: 15px;
        }

        .footer-text a {
            color: #007BFF;
            text-decoration: none;
        }

        .footer-text a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Create Your Account</h1>
        <p class="subtitle">Sign up to get started</p>
        
        <!-- Sign Up Form -->

        <form id="signupForm" autocomplete="off" method="post" action="save_userdata.php"  onsubmit="return handleSubmit(event)">
           <input type="hidden" name="id" value="<?php echo $user_id; ?>">
 
        <!-- Full Name Field -->
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="Full_name" placeholder="Enter your full name" value="<?php echo $full_name ?>" required>
          
            <!-- Email Field -->
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo $email ?>" required>
            
          <!-- Password Field -->
<label for="password">Password:</label>
<div style="position: relative;">
    <input type="password" id="password" name="password" placeholder="Create a password" value="<?php echo $password ?>" required minlength="8">
    <i class="bi bi-eye-fill" id="togglePassword" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); cursor:pointer; color:#555;"></i>
</div>

<!-- Confirm Password Field -->
<label for="confirmPassword">Confirm Password:</label>
<div style="position: relative;">
    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required minlength="8">
    <i class="bi bi-eye-fill" id="toggleConfirmPassword" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); cursor:pointer; color:#555;"></i>
</div>
            
            <!-- Terms and Conditions -->
            <div class="checkbox-container">
                <input type="checkbox" id="terms" name="terms" required>
                <label for="terms">I agree to the <a href="terms.html">terms and conditions</a></label>
            </div>

            <!-- Sign Up Button -->
            <button type="submit"  name="submit" class="btn signup-btn" id="signupBtn">Sign Up</button>

            <!-- Feedback Message -->
            <div id="feedback"></div>
        </form>

        <!-- Divider -->
        <div class="divider">OR</div>

        <button class="btn google-btn" id="googleBtn">
            <!-- Google logo (SVG) -->
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="20" height="20" class="mr-2">
                <path d="M23.49 12.3c0-.73-.06-1.43-.18-2.09H12v4.09h6.23c-0.27 1.56-1.04 2.89-2.42 3.6v3h3.91c2.29-2.11 3.59-5.24 3.59-8.6z" fill="#4285F4"/>
                <path d="M12 7.91c1.11 0 2.05.37 2.8.99l2.1-2.1C15.1 5.01 13.48 4 12 4 8.29 4 5.13 6.53 5.13 9.91s3.16 5.91 6.87 5.91c2.39 0 4.47-1.06 5.93-2.77l-2.1-2.1c-.81.54-1.81.86-3.03.86-2.33 0-4.23-1.59-4.23-3.6s1.9-3.6 4.23-3.6z" fill="#34A853"/>
                <path d="M7.13 9.91c0-1.05.35-2.01.94-2.77L5.07 5.04C3.16 7.18 3.16 9.91 3.16 9.91s3.16 2.73 5.97 2.73c.64 0 1.26-.12 1.86-.34L7.13 9.91z" fill="#FBBC05"/>
                <path d="M12 4c-.77 0-1.5.24-2.1.66l-2.1-2.1C8.29 2.07 10.13 1 12 1c3.13 0 5.81 2.24 5.81 5.91 0 .56-.13 1.09-.36 1.59l-2.28-1.49c-.18-.57-.7-.97-1.24-.97-1.3 0-2.36 1.06-2.36 2.36 0 1.3 1.06 2.36 2.36 2.36 1.19 0 2.25-.87 2.34-2.02l3.47 3.49C23.65 16.91 24 15.52 24 14c0-5.28-3.69-9.91-8.69-9.91z" fill="#EA4335"/>
            </svg>
            Continue with Google
        </button>

        <!-- Sign In Link -->
        <p class="footer-text">Already have an account? <a href="signin.php"0>Sign in here</a>.</p>
    </div>

    <script>
        const googleBtn = document.getElementById('googleBtn');

        // Redirect to account page on clicking "Continue with Google"
        googleBtn.addEventListener('click', () => {
            window.location.href = 'account.html';
        });

        // Handle Form Submission
//         function handleSubmit(event) {
//             event.preventDefault();

//             const email = document.getElementById('email').value;
//             const password = document.getElementById('password').value;
//             const confirmPassword = document.getElementById('confirmPassword').value;

//             if (password.length !== 8) {
//                 document.getElementById('feedback').innerText = "Password should be 8 characters.";
//                 document.getElementById('feedback').style.color = "red";
//                 return false; // Prevent form submission
//             }

//             if (password !== confirmPassword) {
//                 document.getElementById('feedback').innerText = "Passwords do not match.";
//                 document.getElementById('feedback').style.color = "red";
//                 return false; // Prevent form submission
//             }

//             // Save user data (you can add more functionality here like sending data to server)
//             localStorage.setItem("userEmail", email);
//             localStorage.setItem("userPassword", password);

//             document.getElementById('feedback').innerText = "Account successfully created!";
//             document.getElementById('feedback').style.color = "green";
//  setTimeout(function() {
//             window.location.href = 'homepage.php'; // Change to your homepage URL
//         }, 2000);  // 2 seconds delay to show feedback before redirect

     
//             return true; // Proceed with form submission
//         }
    </script>
</body>
</html>
