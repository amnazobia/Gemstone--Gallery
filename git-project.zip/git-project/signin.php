<?php
session_start();
// The include must be the very first thing to prevent header errors later
include 'db.php'; 

$conn = db::getInstance()->getConnection();
$feedback = "";

if (isset($_POST['submit'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password']; // Plain text password

    if (empty($email) || empty($password)) {
        $feedback = "Please enter both email and password.";
    } else {
        // Prepare statement to select user by email
        $stmt = $conn->prepare("SELECT id, Full_name, email, password FROM registration WHERE email = ?");
        
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // INSECURE COMPARISON: Comparing plain text input to plain text from DB
            if ($password === $user['password']) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['Full_name'];
                $_SESSION['user_email'] = $user['email'];

                // Redirect BEFORE any HTML output
                header("Location: homepage.php");
                exit; // Stop script execution immediately
            } else {
                $feedback = "Invalid password.";
            }
        } else {
            $feedback = "No user found with this email.";
        }
    }
    // Close statement if not already closed
    $stmt->close();
}
// Close connection at the end of the script if necessary
// $conn->close(); 
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .error-message {
            color: red; /* Red text for error */
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
     <?php if($feedback) echo "<div class='error-message'>$feedback</div>"; ?>
    <div class="form-container">
        <h1>Sign In</h1>
        <form id="signinForm" autocomplete="off"  method="POST" action="">
            <!-- Email Field -->
            <label for="signinEmail">Email:</label>
            <input type="email" id="signinEmail" name="email" placeholder="Enter your email" required>
            
            <!-- Password Field -->
            <label for="signinPassword">Password:</label>
            <input type="password" id="signinPassword" name="password" placeholder="Enter your password" required>

            <!-- Sign In Button -->
            <button type="submit" name="submit" class="signin-btn">Sign In</button>

            <!-- Feedback -->
            <div id="signinFeedback" class="error-message"></div>
        </form>
        <p class="footer-text">Don't have an account? <a href="register.php">Sign up here</a>.</p>
    </div>

    <script>
        // function handleSignIn(event) {
        //     event.preventDefault();

        //     // Get credentials from the form
        //     const email = document.getElementById('signinEmail').value;
        //     const password = document.getElementById('signinPassword').value;

        //     // Retrieve stored user data
        //     const storedUser = JSON.parse(localStorage.getItem('registeredUser'));

        //     // Password length validation
        //     // if (password.length > 8) {
        //     //     document.getElementById('signinFeedback').innerText = "Password must be 8 characters or less.";
        //     //     document.getElementById('signinFeedback').style.color = "red";
        //     //     return false;
        //     // }

        //     // Validate credentials
        //     if (storedUser && storedUser.email === email && storedUser.password === password) {
        //         document.getElementById('signinFeedback').innerText = "Sign-in successful! Redirecting...";
        //         document.getElementById('signinFeedback').style.color = "green"; // Success feedback
        //         setTimeout(() => {
        //             window.location.href = 'homepage.html'; // Redirect to dashboard/homepage
        //         }, 2000);
        //     } else {
        //         document.getElementById('signinFeedback').innerText = "Invalid email or password.";
        //         document.getElementById('signinFeedback').style.color = "red"; // Error feedback
        //     }
        // }
   </script>
</body>
</html>
